---
name: workload-api-external-agent
description: >-
  Configures external Agents (Kimiclaw / OpenClaw, HTTP toolchains, etc.) to call WorkEvolutionSys
  workload API over HTTPS. Covers base URL, health check, JWT login, Bearer usage,
  response envelope, Excel→Kimi 解析→Kimi 评估→Markdown 草稿导出（Agent 侧转 PDF）、
  minimal curl. Use when integrating bots, MCP HTTP clients, or third-party automation
  with this repository's API or when the user mentions external Agent API setup,
  loca.lt tunnel, Kimiclaw demo, or public API access.
---

# Workload API — 外部 Agent（Kimiclaw）配置与演示

## 运行事实（以代码为准）

- 唯一 HTTP 前缀：`{BASE}/api/v1`（`BASE` = 部署根，无尾部斜杠）。
- 鉴权：**JWT**，请求头 `Authorization: Bearer <token>`。不要使用 `X-Role` 作为权限依据。
- 成功响应形态：`{ "code": 0, "message": "ok", "data": ... , "requestId"?: string }`（**下载类接口见下条，可能非 JSON**）。
- 失败响应：`code` 非 0，常伴 `message`、`details`；HTTP 状态与业务码对应（401/403/400 等）。
- **未提供**专用 `/api/v1/agent/*` 路由；集成走现有业务接口（`auth`、`ai`、`templates`、`rule-sets`、`estimates` 等）。

## 演示 1：连接系统并「记住」用户

**目标**：Kimiclaw 能稳定调用 API，不因每次对话丢失身份。

1. **持久化 JWT（推荐）**
   - 在 Agent 侧配置或密钥库保存：`WES_BASE`、`WES_USER`、`WES_PASS`。
   - 首次或 Token 失效时：`POST {BASE}/api/v1/auth/login`，JSON `{"username","password"}`，读取 `data.token`。
   - 后续所有需鉴权请求带：`Authorization: Bearer <token>`。
2. **探活与校验**
   - `GET {BASE}/api/v1/health`（可无 Token）。
   - `GET {BASE}/api/v1/auth/me`（需 Bearer）确认当前用户与角色。
3. **401 处理**
   - 若 HTTP 401 或业务 `details` 含 `invalid_or_expired_token`，重新执行登录并覆盖已存 Token。
4. **隧道**：`loca.lt` 等若插入浏览器验证页，非浏览器 Agent 会收到 HTML；需在隧道侧关闭验证或换可达公网入口。

## 演示 2：上传需求 Excel → Kimi 解析 + Kimi 评估 → 草稿交付（Markdown / 转 PDF）

**业务链**（与需求页人工流程等价，全部由 API 完成）：

| 步骤 | 方法 | 路径 | 说明 |
|------|------|------|------|
| A | `POST` | `/api/v1/ai/parse-basic-info` | `multipart/form-data`，字段名 **`file`**，上传与需求页相同的 **Excel**。返回 JSON：`data.basicInfo`、`data.requirementImportData`（及 `model`/`mode` 等）。 |
| B | `POST` | `/api/v1/ai/kimi-assessment/preview` | JSON：`source`（可选 `globalVersionCode` / `requirementVersionCode`）、**`requirementSnapshot`**（见下文拼装规则）。返回 `data.assessmentDraft`、`data.meta` 等。 |
| C | `POST` | `/api/v1/ai/kimi-assessment/export-markdown` | JSON：`{ "assessmentDraft": <preview 返回的 draft>, "meta": <可选 preview.meta>, "projectName": "<可选>" }`。响应为 **`text/markdown` 附件**（非 `{code,data}` 包络）。Agent 可用 **pandoc / 打印为 PDF / Kimiclaw 内置文档转 PDF** 生成 PDF 并发送给用户。 |

**`requirementSnapshot` 拼装（与前端 `requirement-import` 提交评估时一致）**

从步骤 A 的返回中取：

- `basicInfo` → 直接作为 `requirementSnapshot.basicInfo`（对象）。
- `requirementImportData` 内各数组 → 对应快照字段（行对象可保留 `id` 等额外字段，后端可容忍）：
  - `valuePropositionRows`
  - `businessNeedRows`
  - `devOverviewRows`
  - `productModuleRows`
  - `implementationScopeRows`
  - `keyPointRows`
- `meetingNotes`：字符串，缺省用 `""`。
- `devTotalDays`（可选）：建议对 `devOverviewRows` 的 `codingDays` 求和后按前端习惯乘 **1.6** 再保留一位小数；若无开发行可传 `0` 或省略。

**最小 JSON 骨架（步骤 B body）**

```json
{
  "source": { "globalVersionCode": "", "requirementVersionCode": "" },
  "requirementSnapshot": {
    "basicInfo": {},
    "valuePropositionRows": [],
    "businessNeedRows": [],
    "devOverviewRows": [],
    "devTotalDays": 0,
    "productModuleRows": [],
    "implementationScopeRows": [],
    "meetingNotes": "",
    "keyPointRows": []
  }
}
```

将步骤 A 的 `basicInfo` / `requirementImportData` 各数组填入对应键即可。

**步骤 C：下载 Markdown（curl 保存文件）**

```bash
curl -sS -X POST "${API}/ai/kimi-assessment/export-markdown" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{\"assessmentDraft\":$(jq '.data.assessmentDraft' preview.json),\"meta\":$(jq '.data.meta' preview.json),\"projectName\":\"演示项目\"}" \
  -o "Kimi评估草稿.md"
```

（将 `preview.json` 换为步骤 B 保存的响应体；若 shell 拼装困难，可用 Kimiclaw 两步调用：先取 JSON 再组 body。）

**关于「发送 PDF」**

- 服务端当前提供 **Markdown 附件**，避免在无中文字体文件时 PDF 乱码；**由 Kimiclaw 将 `.md` 转为 PDF 再发送**即可满足演示。
- 若必须服务端直接出 PDF：需自行扩展（例如配置 `WES_KIMI_ASSESSMENT_PDF_FONT_TTF` 指向 `.ttf` 并用 pdfkit 注册字体），本 Skill 不依赖该变量。

## 首次配置清单（Agent 侧）

1. **设置 `BASE`**：公网或内网可访问的 API 根；本地 `http://localhost:3000`。
2. **探活**：`GET {BASE}/api/v1/health`。
3. **登录**：`POST {BASE}/api/v1/auth/login` → `data.token`。
4. **后续请求**：`Authorization: Bearer <token>`；`Content-Type: application/json`（**上传接口**为 `multipart/form-data`）。
5. **Token 过期**：401 时重新登录。

## 账号前提

- 注册需有效 **邀请码**（`POST /api/v1/auth/register`）。
- `parse-basic-info`、`kimi-assessment/*` 需 **admin 或 operator**（与路由 `requireRole` 一致）。

## 最小 curl 模板（复制后替换变量）

```bash
BASE="https://your-api-host"   # 改为实际部署根
API="${BASE}/api/v1"

curl -sS "${API}/health"

TOKEN=$(curl -sS -X POST "${API}/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"${WES_USER}\",\"password\":\"${WES_PASS}\"}" \
  | jq -r '.data.token')

curl -sS "${API}/auth/me" -H "Authorization: Bearer ${TOKEN}"
```

## 常用只读 / 业务入口（均需 Bearer，除非另有说明）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/v1/health` | 无需 Token |
| POST | `/api/v1/auth/login` | 取 Token |
| GET | `/api/v1/auth/me` | 校验当前用户 |
| POST | `/api/v1/ai/parse-basic-info` | Excel → Kimi（或规则）解析需求结构 |
| POST | `/api/v1/ai/kimi-assessment/preview` | Kimi 实施评估草稿（JSON） |
| POST | `/api/v1/ai/kimi-assessment/export-markdown` | 将草稿导出为 Markdown 附件 |
| GET | `/api/v1/templates` | 模板列表 |
| GET | `/api/v1/rule-sets/active` | 当前规则集 |
| POST | `/api/v1/estimates/calculate` | 工作量计算 |

更完整契约见仓库 `docs/openapi.yaml` 与 `03_技术设计/系统演进/实现与文档对齐说明.md`。

## 给 Agent 系统提示的摘要句（可粘贴）

在同一 `BASE` 下调用 `GET /api/v1/health` 确认服务；用 `POST /api/v1/auth/login` 获取 `data.token` 并持久化；所有需登录接口加 `Authorization: Bearer <token>`；JSON 接口只解析 `code===0` 的 `data`；401 时重新登录。需求评估链：`multipart` 调 `parse-basic-info` → 拼装 `requirementSnapshot` → `POST …/kimi-assessment/preview` → `POST …/export-markdown` 下载草稿，再将 Markdown 转为 PDF 发送用户。
